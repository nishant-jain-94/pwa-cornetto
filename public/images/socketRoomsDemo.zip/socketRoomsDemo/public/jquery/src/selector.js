define( [ "./selector-sizzle" ], function() {} );
