## Socket Room Demo
- Gives demo of use of sockets with dynamic rooms 
- App is in MEAN stack